// Smart Energy Monitor Firmware - ESP32
// INA219 over I2C, UART command line, ring buffer, state machine, watchdog, fault log.
#include <Arduino.h>
#include <Preferences.h>
#include <Wire.h>
#include <esp_system.h>
#include <esp_task_wdt.h>

#include "ina219.h"
#include "ring_buffer.h"

constexpr uint8_t LED_PIN = 2;  // onboard LED on most ESP32 dev boards
constexpr uint32_t WDT_TIMEOUT_S = 5;

enum class State { IDLE, SAMPLING, REPORTING, FAULT };

Ina219 sensor(Wire, 0x40, 0.1f);
RingBuffer<128> rxBuf;
Preferences prefs;

State state = State::IDLE;
uint32_t intervalMs = 100;
float limit_mA = 1000.0f;
uint32_t lastSampleMs = 0, sampleCount = 0, i2cErrors = 0;
float lastV = 0, lastI = 0;
String line;

const char *stateName(State s) {
  switch (s) {
    case State::IDLE: return "IDLE";
    case State::SAMPLING: return "SAMPLING";
    case State::REPORTING: return "REPORTING";
    case State::FAULT: return "FAULT";
  }
  return "?";
}

void enterFault(float current_mA) {
  state = State::FAULT;
  digitalWrite(LED_PIN, HIGH);
  prefs.begin("fault", false);
  prefs.putFloat("current_mA", current_mA);
  prefs.putULong("uptime_ms", millis());
  prefs.putUInt("count", prefs.getUInt("count", 0) + 1);
  prefs.end();
  Serial.printf("FAULT,current_mA=%.1f,limit_mA=%.1f\n", current_mA, limit_mA);
}

void printFaultLog() {
  prefs.begin("fault", true);
  Serial.printf("FAULTLOG,count=%u,last_current_mA=%.1f,last_uptime_ms=%lu\n",
                prefs.getUInt("count", 0), prefs.getFloat("current_mA", 0),
                prefs.getULong("uptime_ms", 0));
  prefs.end();
}

void handleCommand(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;
  String arg = "";
  int sp = cmd.indexOf(' ');
  if (sp > 0) { arg = cmd.substring(sp + 1); cmd = cmd.substring(0, sp); }

  if (cmd == "status") {
    Serial.printf("STATUS,state=%s,interval_ms=%lu,limit_mA=%.1f\n", stateName(state), intervalMs, limit_mA);
  } else if (cmd == "read") {
    float v, i;
    if (sensor.read(v, i)) Serial.printf("READ,bus_V=%.3f,current_mA=%.1f\n", v, i);
    else { i2cErrors++; Serial.println("ERR,i2c_read_failed"); }
  } else if (cmd == "start") {
    if (state == State::FAULT) Serial.println("ERR,in_fault_use_reset");
    else { state = State::SAMPLING; Serial.println("OK,started"); }
  } else if (cmd == "stop") {
    if (state != State::FAULT) state = State::IDLE;
    Serial.println("OK,stopped");
  } else if (cmd == "set_interval") {
    long v = arg.toInt();
    if (v >= 10 && v <= 10000) { intervalMs = v; Serial.println("OK,interval_set"); }
    else Serial.println("ERR,interval_range_10_10000");
  } else if (cmd == "set_limit") {
    float v = arg.toFloat();
    if (v > 0) { limit_mA = v; Serial.println("OK,limit_set"); }
    else Serial.println("ERR,bad_limit");
  } else if (cmd == "reset") {
    digitalWrite(LED_PIN, LOW);
    state = State::IDLE;
    Serial.println("OK,reset");
  } else if (cmd == "faultlog") {
    printFaultLog();
  } else if (cmd == "stats") {
    Serial.printf("STATS,samples=%lu,i2c_errors=%lu,rx_dropped=%lu,uptime_s=%lu\n",
                  sampleCount, i2cErrors, rxBuf.dropped(), millis() / 1000);
  } else if (cmd == "crash") {
    Serial.println("OK,hanging_to_test_watchdog");
    while (true) {}  // loop() stops feeding the watchdog -> reset
  } else {
    Serial.println("ERR,unknown_command");
  }
}

void runStateMachine() {
  uint32_t now = millis();
  switch (state) {
    case State::IDLE:
    case State::FAULT:
      break;
    case State::SAMPLING:
      if (now - lastSampleMs >= intervalMs) {
        lastSampleMs = now;
        if (!sensor.read(lastV, lastI)) { i2cErrors++; break; }
        sampleCount++;
        if (fabsf(lastI) > limit_mA) enterFault(lastI);
        else state = State::REPORTING;
      }
      break;
    case State::REPORTING:
      Serial.printf("DATA,%lu,%.3f,%.1f\n", now, lastV, lastI);
      state = State::SAMPLING;
      break;
  }
}

void setup() {
  Serial.begin(115200);
  // Bytes arriving on UART are pushed into the ring buffer from the receive callback.
  Serial.onReceive([]() {
    while (Serial.available()) rxBuf.push((uint8_t)Serial.read());
  });
  pinMode(LED_PIN, OUTPUT);
  Wire.begin(21, 22);
  Wire.setClock(400000);
  esp_task_wdt_init(WDT_TIMEOUT_S, true);  // panic + reset if loop() stalls
  esp_task_wdt_add(NULL);
  bool ok = sensor.begin();
  Serial.printf("BOOT,reset_reason=%d,ina219=%s\n", (int)esp_reset_reason(), ok ? "ok" : "NOT_FOUND");
}

void loop() {
  esp_task_wdt_reset();
  uint8_t c;
  while (rxBuf.pop(c)) {
    if (c == '\n' || c == '\r') { handleCommand(line); line = ""; }
    else if (line.length() < 64) line += (char)c;
  }
  runStateMachine();
}
