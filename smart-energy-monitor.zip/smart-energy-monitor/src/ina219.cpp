#include "ina219.h"

namespace {
constexpr uint8_t REG_CONFIG = 0x00;
constexpr uint8_t REG_SHUNT_V = 0x01;
constexpr uint8_t REG_BUS_V = 0x02;
constexpr uint16_t CONFIG_DEFAULT = 0x399F;  // 32V range, +/-320mV shunt, 12-bit, continuous
}  // namespace

Ina219::Ina219(TwoWire &wire, uint8_t addr, float shunt_ohm)
    : wire_(wire), addr_(addr), shunt_ohm_(shunt_ohm) {}

bool Ina219::writeReg(uint8_t reg, uint16_t val) {
  wire_.beginTransmission(addr_);
  wire_.write(reg);
  wire_.write(val >> 8);
  wire_.write(val & 0xFF);
  return wire_.endTransmission() == 0;
}

bool Ina219::readReg(uint8_t reg, uint16_t &val) {
  wire_.beginTransmission(addr_);
  wire_.write(reg);
  if (wire_.endTransmission() != 0) return false;
  if (wire_.requestFrom((int)addr_, 2) != 2) return false;
  uint16_t hi = wire_.read();
  uint16_t lo = wire_.read();
  val = (hi << 8) | lo;  // big-endian
  return true;
}

bool Ina219::begin() { return writeReg(REG_CONFIG, CONFIG_DEFAULT); }

bool Ina219::read(float &bus_V, float &current_mA) {
  uint16_t shunt_raw, bus_raw;
  if (!readReg(REG_SHUNT_V, shunt_raw)) return false;
  if (!readReg(REG_BUS_V, bus_raw)) return false;
  // Shunt register LSB = 10 uV (signed). I = V / R.
  float shunt_mV = (int16_t)shunt_raw * 0.01f;
  current_mA = shunt_mV / shunt_ohm_;
  // Bus voltage: bits 15..3, LSB = 4 mV.
  bus_V = (bus_raw >> 3) * 0.004f;
  return true;
}
