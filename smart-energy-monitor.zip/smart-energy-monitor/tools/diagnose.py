#!/usr/bin/env python3
"""Diagnostic CLI for the Smart Energy Monitor firmware (pyserial)."""
import argparse
import csv
import time

import serial


def open_port(port, baud):
    s = serial.Serial(port, baud, timeout=0.2)
    time.sleep(2)  # ESP32 resets when the port opens
    s.reset_input_buffer()
    return s


def send(s, cmd, wait=0.4):
    s.write((cmd + "\n").encode())
    time.sleep(wait)
    out = []
    while s.in_waiting:
        out.append(s.readline().decode(errors="replace").strip())
    return [l for l in out if l]


def monitor(s, duration, csv_path):
    send(s, "start", 0.2)
    rows, faults = [], []
    t0 = time.time()
    try:
        while time.time() - t0 < duration:
            raw = s.readline().decode(errors="replace").strip()
            if raw.startswith("DATA,"):
                _, ms, v, i = raw.split(",")
                rows.append((int(ms), float(v), float(i)))
                print(f"{float(v):6.3f} V  {float(i):8.1f} mA")
            elif raw.startswith("FAULT"):
                faults.append(raw)
                print(raw)
                break
    except KeyboardInterrupt:
        pass
    elapsed = time.time() - t0
    send(s, "stop", 0.2)
    stats = send(s, "stats", 0.4)
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["uptime_ms", "bus_V", "current_mA"])
        w.writerows(rows)
    print("\n--- Summary ---")
    print(f"Samples received : {len(rows)}")
    print(f"Duration         : {elapsed:.1f} s ({elapsed / 3600:.3f} h)")
    print(f"Samples per sec  : {len(rows) / elapsed:.2f}")
    print(f"Faults           : {len(faults)}")
    for l in stats:
        print(f"Firmware         : {l}")
    print(f"CSV saved to     : {csv_path}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--port", required=True, help="e.g. COM5 or /dev/ttyUSB0")
    p.add_argument("--baud", type=int, default=115200)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("status", "read", "faultlog", "stats", "reset", "crash"):
        sub.add_parser(name)
    si = sub.add_parser("set-interval"); si.add_argument("ms", type=int)
    sl = sub.add_parser("set-limit"); sl.add_argument("mA", type=float)
    m = sub.add_parser("monitor")
    m.add_argument("--duration", type=int, default=60, help="seconds")
    m.add_argument("--csv", default="log.csv")
    a = p.parse_args()

    s = open_port(a.port, a.baud)
    if a.cmd == "monitor":
        monitor(s, a.duration, a.csv)
    else:
        cmd = {"set-interval": f"set_interval {getattr(a, 'ms', '')}",
               "set-limit": f"set_limit {getattr(a, 'mA', '')}"}.get(a.cmd, a.cmd)
        for line in send(s, cmd):
            print(line)
    s.close()


if __name__ == "__main__":
    main()
