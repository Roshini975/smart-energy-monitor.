#pragma once
#include <stddef.h>
#include <stdint.h>
#include <atomic>

// Lock-free single-producer / single-consumer ring buffer.
// Producer: UART receive callback. Consumer: main loop.
template <size_t N>
class RingBuffer {
 public:
  bool push(uint8_t b) {
    size_t h = head_.load(std::memory_order_relaxed);
    size_t next = (h + 1) % N;
    if (next == tail_.load(std::memory_order_acquire)) {  // full
      dropped_++;
      return false;
    }
    buf_[h] = b;
    head_.store(next, std::memory_order_release);
    return true;
  }
  bool pop(uint8_t &b) {
    size_t t = tail_.load(std::memory_order_relaxed);
    if (t == head_.load(std::memory_order_acquire)) return false;  // empty
    b = buf_[t];
    tail_.store((t + 1) % N, std::memory_order_release);
    return true;
  }
  uint32_t dropped() const { return dropped_; }

 private:
  uint8_t buf_[N];
  std::atomic<size_t> head_{0}, tail_{0};
  uint32_t dropped_ = 0;
};
