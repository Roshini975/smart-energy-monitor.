#pragma once
#include <Wire.h>

// Minimal INA219 driver written directly against the register map (no vendor library).
class Ina219 {
 public:
  Ina219(TwoWire &wire, uint8_t addr = 0x40, float shunt_ohm = 0.1f);
  bool begin();
  // Returns false on any I2C error.
  bool read(float &bus_V, float &current_mA);

 private:
  bool readReg(uint8_t reg, uint16_t &val);
  bool writeReg(uint8_t reg, uint16_t val);
  TwoWire &wire_;
  uint8_t addr_;
  float shunt_ohm_;
};
